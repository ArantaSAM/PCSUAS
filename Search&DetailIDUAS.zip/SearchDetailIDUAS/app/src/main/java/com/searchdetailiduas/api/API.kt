package com.searchdetailiduas.api

import com.searchdetailiduas.Model.RespondUser
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface API {
    @GET("search/users")
    @Headers("Authorization: token ea382b9bf3b7e5c62a19b8d67d8a9dd95f82396d")
    fun getSearchUser(
        @Query("q") query: String
    ): Call<RespondUser>
}