package com.searchdetailiduas.Model

data class User (
    val login: String,
    val id: Int,
    val avatar_url:String
        )